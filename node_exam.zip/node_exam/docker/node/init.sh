#!/bin/bash

set -e

npm install
#npm run start

tail -f /dev/null